# __init__.py

from .core import find_keyword_xtvu  # Importation de la fonction depuis le fichier core.py

__all__ = ["find_keyword_xtvu"]  # Définit ce qui est exposé lorsque le module est importé
